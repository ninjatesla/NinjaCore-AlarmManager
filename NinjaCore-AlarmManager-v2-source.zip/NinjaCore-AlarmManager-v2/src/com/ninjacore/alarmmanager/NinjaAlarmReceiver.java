package com.ninjacore.alarmmanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NinjaAlarmReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context context, Intent intent) {
    if (NinjaAlarmManager.ACTION_ALARM.equals(intent.getAction())) {
      NinjaAlarmManager.handleAlarm(context, intent);
    }
  }
}
