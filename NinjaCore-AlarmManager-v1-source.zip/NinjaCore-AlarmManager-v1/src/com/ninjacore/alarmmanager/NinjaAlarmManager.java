package com.ninjacore.alarmmanager;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.ContextCompat;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesBroadcastReceivers;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.annotations.androidmanifest.ActionElement;
import com.google.appinventor.components.annotations.androidmanifest.IntentFilterElement;
import com.google.appinventor.components.annotations.androidmanifest.ReceiverElement;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.PropertyCategory;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.PermissionResultHandler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@DesignerComponent(
    version = 1,
    description = "NinjaCore Alarm Manager V1. Background repeating alarms and notifications for MIT App Inventor.",
    category = ComponentCategory.EXTENSION,
    nonVisible = true,
    iconName = "images/alarm.png"
)
@SimpleObject(external = true)
@UsesPermissions({
    Manifest.permission.POST_NOTIFICATIONS,
    Manifest.permission.RECEIVE_BOOT_COMPLETED
})
@UsesBroadcastReceivers(receivers = {
    @ReceiverElement(
        name = "com.ninjacore.alarmmanager.NinjaAlarmReceiver",
        exported = false,
        intentFilters = {
            @IntentFilterElement(actionElements = {
                @ActionElement(name = "com.ninjacore.alarmmanager.ACTION_ALARM")
            })
        }
    )
})
public class NinjaAlarmManager extends AndroidNonvisibleComponent {

  static final String ACTION_ALARM = "com.ninjacore.alarmmanager.ACTION_ALARM";
  static final String EXTRA_ID = "alarm_id";
  static final String EXTRA_TITLE = "alarm_title";
  static final String EXTRA_MESSAGE = "alarm_message";
  static final String CHANNEL_ID = "ninjacore_alarm";

  private static final Map<String, NinjaAlarmManager> INSTANCES = new ConcurrentHashMap<>();

  private final Context context;
  final Form form;
  private int startMode = 4;

  public NinjaAlarmManager(ComponentContainer container) {
    super(container.$form());
    this.context = container.$context();
    this.form = container.$form();
    INSTANCES.put(context.getPackageName(), this);
    createNotificationChannel();
  }

  @SimpleProperty(
      category = PropertyCategory.BEHAVIOR,
      description = "Background start mode. 4 = background processing."
  )
  @DesignerProperty(
      editorType = PropertyTypeConstants.PROPERTY_TYPE_INTEGER,
      defaultValue = "4"
  )
  public int StartMode() {
    return startMode;
  }

  @SimpleProperty
  public void StartMode(int value) {
    startMode = (value >= 1 && value <= 4) ? value : 4;
  }

  @SimpleFunction(description = "Schedule a repeating alarm every N minutes.")
  public void ScheduleRepeatingEveryMinutes(String id, int minutes, String title, String message) {
    if (minutes < 1) minutes = 1;
    scheduleRepeating(id, minutes * 60L * 1000L, title, message);
  }

  @SimpleFunction(description = "Schedule a repeating alarm every N hours.")
  public void ScheduleRepeatingEveryHours(String id, int hours, String title, String message) {
    if (hours < 1) hours = 1;
    scheduleRepeating(id, hours * 60L * 60L * 1000L, title, message);
  }

  @SimpleFunction(description = "Schedule an alarm once, N minutes from now.")
  public void ScheduleOnceInMinutes(String id, int minutesFromNow, String title, String message) {
    if (minutesFromNow < 0) minutesFromNow = 0;
    scheduleOnce(id, System.currentTimeMillis() + minutesFromNow * 60L * 1000L, title, message);
  }

  @SimpleFunction(description = "Cancel an alarm by its ID.")
  public void CancelAlarm(String id) {
    AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    if (am != null) {
      PendingIntent pi = pendingIntent(id, false);
      if (pi != null) {
        am.cancel(pi);
        pi.cancel();
      }
    }
  }

  @SimpleFunction(description = "Returns true if an alarm with this ID is scheduled.")
  public boolean IsAlarmScheduled(String id) {
    return pendingIntent(id, false) != null;
  }

  @SimpleFunction(description = "Opens Android exact-alarm settings when available.")
  public void OpenAlarmPermissionSettings() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
      intent.setData(android.net.Uri.parse("package:" + context.getPackageName()));
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      context.startActivity(intent);
    }
  }

  @SimpleFunction(description = "Requests notification permission on Android 13+.")
  public void RequestNotificationPermission() {
    if (Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
      form.askPermission(Manifest.permission.POST_NOTIFICATIONS, new PermissionResultHandler() {
        @Override
        public void HandlePermissionResponse(String permission, boolean granted) {
          NotificationPermissionResult(granted);
        }
      });
    } else {
      NotificationPermissionResult(true);
    }
  }

  @SimpleEvent(description = "Raised when the alarm receiver runs while the App Inventor runtime is active.")
  public void OnReceive(String title, String text, String startText) {
    EventDispatcher.dispatchEvent(this, "OnReceive", title, text, startText);
  }

  @SimpleEvent(description = "Reports the result of notification permission request.")
  public void NotificationPermissionResult(boolean granted) {
    EventDispatcher.dispatchEvent(this, "NotificationPermissionResult", granted);
  }

  private void scheduleRepeating(String id, long interval, String title, String message) {
    AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;

    PendingIntent pi = pendingIntentWithExtras(id, title, message, true);
    long first = System.currentTimeMillis() + interval;

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      am.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, interval, pi);
    } else {
      am.setRepeating(AlarmManager.RTC_WAKEUP, first, interval, pi);
    }
  }

  private void scheduleOnce(String id, long triggerAt, String title, String message) {
    AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;

    PendingIntent pi = pendingIntentWithExtras(id, title, message, true);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
    } else {
      am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
    }
  }

  private PendingIntent pendingIntent(String id, boolean create) {
    return pendingIntentWithExtras(id, "", "", create);
  }

  private PendingIntent pendingIntentWithExtras(String id, String title, String message, boolean create) {
    Intent intent = new Intent(context, NinjaAlarmReceiver.class);
    intent.setAction(ACTION_ALARM);
    intent.putExtra(EXTRA_ID, id);
    intent.putExtra(EXTRA_TITLE, title);
    intent.putExtra(EXTRA_MESSAGE, message);

    int flags = create ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_NO_CREATE;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
    return PendingIntent.getBroadcast(context, requestCode(id), intent, flags);
  }

  private int requestCode(String id) {
    return id == null ? 0 : id.hashCode();
  }

  private void createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
      if (nm != null) {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "NinjaCore Alarms", NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(channel);
      }
    }
  }

  static void handleAlarm(Context ctx, Intent intent) {
    String id = intent.getStringExtra(EXTRA_ID);
    String title = intent.getStringExtra(EXTRA_TITLE);
    String message = intent.getStringExtra(EXTRA_MESSAGE);
    if (title == null || title.isEmpty()) title = "NinjaCore Alarm";
    if (message == null) message = "";

    if (Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            == android.content.pm.PackageManager.PERMISSION_GRANTED) {
      NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
      if (nm != null) {
        NotificationCompatHelper.show(ctx, id, title, message);
      }
    }

    NinjaAlarmManager manager = INSTANCES.get(ctx.getPackageName());
    if (manager != null) {
      final String fTitle = title;
      final String fMessage = message;
      manager.form.runOnUiThread(new Runnable() {
        @Override public void run() {
          manager.OnReceive(fTitle, fMessage, "background");
        }
      });
    }
  }

  private static final class NotificationCompatHelper {
    static void show(Context ctx, String id, String title, String message) {
      NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
      if (nm == null) return;

      android.app.Notification.Builder b;
      if (Build.VERSION.SDK_INT >= 26) {
        b = new android.app.Notification.Builder(ctx, CHANNEL_ID);
      } else {
        b = new android.app.Notification.Builder(ctx);
      }
      b.setSmallIcon(android.R.drawable.ic_dialog_info)
       .setContentTitle(title)
       .setContentText(message)
       .setAutoCancel(true);

      nm.notify(id == null ? 1 : id.hashCode(), b.build());
    }
  }
}
