# NinjaCore Alarm Manager V1

Custom MIT App Inventor extension for NinjaCore.

## V1 goal
- Repeating alarm every N minutes
- Repeating alarm every N hours
- One-shot alarm in N minutes
- Cancel / scheduled check
- Android notification
- Background BroadcastReceiver
- `StartMode` property (default 4)
- `OnReceive(title, text, startText)` event when the App Inventor runtime is active
- Android 13 notification permission request

## Important limitation in V1
`OnReceive` is an App Inventor event and therefore is dispatched to the active App Inventor runtime when the process is alive. The BroadcastReceiver itself still runs when the app UI is not open and can create a notification. The later Binance background checker should run inside the receiver/extension Java code if we want it to work reliably while the app process is dead.

## First test
1. Import the built `.aix` into MIT App Inventor.
2. Add `NinjaAlarmManager`.
3. Call `RequestNotificationPermission`.
4. Call `ScheduleRepeatingEveryMinutes` with:
   - id: `TEST`
   - minutes: `1`
   - title: `NinjaCore TEST`
   - message: `Background alarm works`
5. Build the APK and install it. Do not rely only on Companion because the receiver is registered in the compiled app manifest.
6. Lock the phone and wait for the notification.

## Next version
After V1 alarm reliability is confirmed:
- background Binance REST request
- scan 1000 bids/asks
- threshold 100 BTC
- notify only on 100+ BTC BID/ASK
- hourly production mode
- reboot rescheduling
- optional exact-alarm mode
