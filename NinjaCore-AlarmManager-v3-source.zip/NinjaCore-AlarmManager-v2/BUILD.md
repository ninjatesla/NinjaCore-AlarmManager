# Build notes

The GitHub Actions workflow is the recommended build path. It uses the official MIT App Inventor extension-template and its dependency update mechanism. The official template requires Java 8, Ant 1.10+, and Git; its build creates `.aix` files under `out/`. See the MIT template documentation for the supported build process.
