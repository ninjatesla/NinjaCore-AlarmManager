package com.ninjacore.alarmmanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Map;

public class NinjaBootReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context context, Intent intent) {
    if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
    SharedPreferences p = context.getSharedPreferences(NinjaAlarmManager.PREFS, Context.MODE_PRIVATE);
    Map<String, ?> all = p.getAll();
    for (String key : all.keySet()) {
      if (key.startsWith("alarm_") && key.endsWith("_repeat")) {
        String id = key.substring("alarm_".length(), key.length() - "_repeat".length());
        NinjaAlarmManager.schedulePersisted(context, id);
      }
    }
  }
}
