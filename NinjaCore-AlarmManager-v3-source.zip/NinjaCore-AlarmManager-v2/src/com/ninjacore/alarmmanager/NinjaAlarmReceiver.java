package com.ninjacore.alarmmanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NinjaAlarmReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context context, Intent intent) {
    if (NinjaAlarmManager.ACTION_ALARM.equals(intent.getAction())) {
      NinjaAlarmManager.handleAlarm(context, intent);

      // Wake the NinjaCore App Inventor runtime so its existing WebREST.Get
      // and WebREST.GotText blocks can run when an alarm fires.
      try {
        Intent launchIntent = context.getPackageManager()
            .getLaunchIntentForPackage(context.getPackageName());
        if (launchIntent != null) {
          launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
              | Intent.FLAG_ACTIVITY_CLEAR_TOP
              | Intent.FLAG_ACTIVITY_SINGLE_TOP);
          context.startActivity(launchIntent);
        }
      } catch (Exception ignored) {
      }
    }
  }
}
