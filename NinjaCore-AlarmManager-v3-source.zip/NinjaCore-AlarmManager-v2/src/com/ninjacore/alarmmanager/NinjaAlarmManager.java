package com.ninjacore.alarmmanager;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesBroadcastReceivers;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.annotations.androidmanifest.ActionElement;
import com.google.appinventor.components.annotations.androidmanifest.IntentFilterElement;
import com.google.appinventor.components.annotations.androidmanifest.ReceiverElement;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.PropertyCategory;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.PermissionResultHandler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@DesignerComponent(
    version = 2,
    description = "NinjaCore background alarm manager for MIT App Inventor.",
    category = ComponentCategory.EXTENSION,
    nonVisible = true,
    iconName = "images/alarm.png")
@SimpleObject(external = true)
@UsesPermissions({
    Manifest.permission.POST_NOTIFICATIONS,
    Manifest.permission.RECEIVE_BOOT_COMPLETED,
    Manifest.permission.SCHEDULE_EXACT_ALARM})
@UsesBroadcastReceivers(receivers = {
    @ReceiverElement(
        name = "com.ninjacore.alarmmanager.NinjaAlarmReceiver",
        exported = false,
        intentFilters = {@IntentFilterElement(actionElements = {
            @ActionElement(name = "com.ninjacore.alarmmanager.ACTION_ALARM")
        })}),
    @ReceiverElement(
        name = "com.ninjacore.alarmmanager.NinjaBootReceiver",
        exported = false,
        intentFilters = {@IntentFilterElement(actionElements = {
            @ActionElement(name = "android.intent.action.BOOT_COMPLETED")
        })})
})
public class NinjaAlarmManager extends AndroidNonvisibleComponent {

  static final String ACTION_ALARM = "com.ninjacore.alarmmanager.ACTION_ALARM";
  static final String EXTRA_ID = "alarm_id";
  static final String EXTRA_TITLE = "alarm_title";
  static final String EXTRA_MESSAGE = "alarm_message";
  static final String EXTRA_REPEAT_MS = "alarm_repeat_ms";
  static final String CHANNEL_ID = "ninjacore_alarm";
  static final String PREFS = "ninjacore_alarm_manager";

  private static final Map<String, NinjaAlarmManager> INSTANCES = new ConcurrentHashMap<String, NinjaAlarmManager>();

  private final Context context;
  final Form form;
  private int startMode = 4;

  public NinjaAlarmManager(ComponentContainer container) {
    super(container.$form());
    context = container.$context();
    form = container.$form();
    INSTANCES.put(context.getPackageName(), this);
    createNotificationChannel();
  }

  @SimpleProperty(category = PropertyCategory.BEHAVIOR,
      description = "Background start mode. 1=notification, 2=above lock screen, 3=start always, 4=background processing.")
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_INTEGER, defaultValue = "4")
  public int StartMode() {
    return startMode;
  }

  @SimpleProperty
  public void StartMode(int value) {
    startMode = (value >= 1 && value <= 4) ? value : 4;
  }

  @SimpleFunction(description = "Schedule a repeating alarm every N minutes.")
  public void ScheduleRepeatingEveryMinutes(String id, int minutes, String title, String message) {
    if (minutes < 1) minutes = 1;
    schedule(id, minutes * 60L * 1000L, title, message, true);
  }

  @SimpleFunction(description = "Schedule a repeating alarm every N hours.")
  public void ScheduleRepeatingEveryHours(String id, int hours, String title, String message) {
    if (hours < 1) hours = 1;
    schedule(id, hours * 60L * 60L * 1000L, title, message, true);
  }

  @SimpleFunction(description = "Schedule an alarm once, N minutes from now.")
  public void ScheduleOnceInMinutes(String id, int minutesFromNow, String title, String message) {
    if (minutesFromNow < 0) minutesFromNow = 0;
    scheduleOnce(id, minutesFromNow * 60L * 1000L, title, message);
  }

  @SimpleFunction(description = "Cancel an alarm by ID.")
  public void CancelAlarm(String id) {
    AlarmManager am = getAlarmManager();
    if (am != null) {
      PendingIntent pi = pendingIntent(id, false);
      if (pi != null) {
        am.cancel(pi);
        pi.cancel();
      }
    }
    preferences().edit().remove(key(id, "repeat")).remove(key(id, "title"))
        .remove(key(id, "message")).apply();
  }

  @SimpleFunction(description = "Returns true when an alarm with this ID is scheduled.")
  public boolean IsAlarmScheduled(String id) {
    return pendingIntent(id, false) != null;
  }

  @SimpleFunction(description = "Open Android exact-alarm permission settings on Android 12+.")
  public void OpenAlarmPermissionSettings() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      try {
        Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
        intent.setData(Uri.parse("package:" + context.getPackageName()));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
      } catch (Exception ignored) {
      }
    }
  }

  @SimpleFunction(description = "Request notification permission on Android 13+.")
  public void RequestNotificationPermission() {
    if (Build.VERSION.SDK_INT >= 33 &&
        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      form.askPermission(Manifest.permission.POST_NOTIFICATIONS, new PermissionResultHandler() {
        @Override
        public void HandlePermissionResponse(String permission, boolean granted) {
          NotificationPermissionResult(granted);
        }
      });
    } else {
      NotificationPermissionResult(true);
    }
  }

  @SimpleEvent(description = "Raised when an alarm fires while the App Inventor runtime is available.")
  public void OnReceive(String title, String text, String startText) {
    EventDispatcher.dispatchEvent(this, "OnReceive", title, text, startText);
  }

  @SimpleEvent(description = "Reports the notification permission result.")
  public void NotificationPermissionResult(boolean granted) {
    EventDispatcher.dispatchEvent(this, "NotificationPermissionResult", granted);
  }

  private void schedule(String id, long repeatMs, String title, String message, boolean repeating) {
    if (repeatMs < 60000L) repeatMs = 60000L;
    saveAlarm(id, repeatMs, title, message, repeating);
    scheduleAt(id, repeatMs, title, message, repeatMs);
  }

  private void scheduleOnce(String id, long delayMs, String title, String message) {
    saveAlarm(id, 0L, title, message, false);
    scheduleAt(id, Math.max(0L, delayMs), title, message, 0L);
  }

  static void schedulePersisted(Context ctx, String id) {
    SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    long repeatMs = p.getLong(key(id, "repeat"), 0L);
    if (repeatMs <= 0L) return;
    String title = p.getString(key(id, "title"), "NinjaCore Alarm");
    String message = p.getString(key(id, "message"), "");
    scheduleAtStatic(ctx, id, repeatMs, title, message, repeatMs);
  }

  private void saveAlarm(String id, long repeatMs, String title, String message, boolean repeating) {
    SharedPreferences.Editor e = preferences().edit();
    e.putLong(key(id, "repeat"), repeating ? repeatMs : 0L);
    e.putString(key(id, "title"), title == null ? "NinjaCore Alarm" : title);
    e.putString(key(id, "message"), message == null ? "" : message);
    e.apply();
  }

  private void scheduleAt(String id, long delayMs, String title, String message, long repeatMs) {
    scheduleAtStatic(context, id, delayMs, title, message, repeatMs);
  }

  static void scheduleAtStatic(Context ctx, String id, long delayMs, String title, String message, long repeatMs) {
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;

    PendingIntent pi = pendingIntentStatic(ctx, id, title, message, repeatMs, true);
    long trigger = System.currentTimeMillis() + Math.max(1000L, delayMs);

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms()) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi);
      }
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
    } else {
      am.set(AlarmManager.RTC_WAKEUP, trigger, pi);
    }
  }

  static void handleAlarm(Context ctx, Intent intent) {
    String id = intent.getStringExtra(EXTRA_ID);
    String title = intent.getStringExtra(EXTRA_TITLE);
    String message = intent.getStringExtra(EXTRA_MESSAGE);
    long repeatMs = intent.getLongExtra(EXTRA_REPEAT_MS, 0L);

    if (title == null || title.length() == 0) title = "NinjaCore Alarm";
    if (message == null) message = "";

    showNotification(ctx, id, title, message);

    // Re-arm repeating alarms as exact one-shot alarms. This survives Doze better than
    // setRepeating and lets the receiver keep control of the interval.
    if (repeatMs > 0L) {
      SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
      if (p.getLong(key(id, "repeat"), 0L) > 0L) {
        scheduleAtStatic(ctx, id, repeatMs, title, message, repeatMs);
      }
    } else if (id != null) {
      ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
          .remove(key(id, "repeat")).remove(key(id, "title")).remove(key(id, "message")).apply();
    }

    NinjaAlarmManager manager = INSTANCES.get(ctx.getPackageName());
    if (manager != null) {
      final String fTitle = title;
      final String fMessage = message;
      manager.form.runOnUiThread(new Runnable() {
        @Override public void run() {
          manager.OnReceive(fTitle, fMessage, "background");
        }
      });
    }
  }

  private static void showNotification(Context ctx, String id, String title, String message) {
    if (Build.VERSION.SDK_INT >= 33 &&
        ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      return;
    }
    NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
    if (nm == null) return;
    android.app.Notification.Builder b;
    if (Build.VERSION.SDK_INT >= 26) {
      b = new android.app.Notification.Builder(ctx, CHANNEL_ID);
    } else {
      b = new android.app.Notification.Builder(ctx);
    }
    b.setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle(title)
        .setContentText(message)
        .setAutoCancel(true);
    nm.notify(id == null ? 1 : id.hashCode(), b.build());
  }

  private void createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
      if (nm != null) {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "NinjaCore Alarms", NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(channel);
      }
    }
  }

  private AlarmManager getAlarmManager() {
    return (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
  }

  private SharedPreferences preferences() {
    return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
  }

  private static PendingIntent pendingIntentStatic(Context ctx, String id, String title,
                                                   String message, long repeatMs, boolean create) {
    Intent intent = new Intent(ctx, NinjaAlarmReceiver.class);
    intent.setAction(ACTION_ALARM);
    intent.putExtra(EXTRA_ID, id);
    intent.putExtra(EXTRA_TITLE, title);
    intent.putExtra(EXTRA_MESSAGE, message);
    intent.putExtra(EXTRA_REPEAT_MS, repeatMs);
    int flags = create ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_NO_CREATE;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
    return PendingIntent.getBroadcast(ctx, requestCode(id), intent, flags);
  }

  private PendingIntent pendingIntent(String id, boolean create) {
    return pendingIntentStatic(context, id, "", "", 0L, create);
  }

  private static int requestCode(String id) {
    return id == null ? 0 : id.hashCode();
  }

  private static String key(String id, String suffix) {
    return "alarm_" + (id == null ? "null" : id) + "_" + suffix;
  }
}
