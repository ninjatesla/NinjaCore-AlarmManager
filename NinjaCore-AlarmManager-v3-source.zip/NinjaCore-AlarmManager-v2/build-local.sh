#!/usr/bin/env bash
set -e
rm -rf /tmp/ninjacore-extension-template
git clone --depth 1 --recurse-submodules https://github.com/mit-cml/extension-template.git /tmp/ninjacore-extension-template
cd /tmp/ninjacore-extension-template
chmod +x upgrade-appinventor.sh
./upgrade-appinventor.sh
rm -rf src/*
cp -R /path/to/NinjaCore-AlarmManager/src/. src/
ant clean
ant extensions
ls -lh out/*.aix
