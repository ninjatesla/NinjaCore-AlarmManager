# NinjaCore Alarm Manager V2

Custom Android alarm extension for MIT App Inventor.

## Goal
Provide a small, independent background alarm engine for NinjaCore without changing the existing Liquidity Radar blocks.

## V2 features
- `StartMode` property: 1-4, default 4
- `ScheduleRepeatingEveryMinutes`
- `ScheduleRepeatingEveryHours`
- `ScheduleOnceInMinutes`
- `CancelAlarm`
- `IsAlarmScheduled`
- `OpenAlarmPermissionSettings`
- `RequestNotificationPermission`
- `OnReceive(title, text, startText)` when the App Inventor runtime is alive
- Android notification from the background receiver
- Alarm persistence and rescheduling after device reboot
- Exact-alarm support with inexact fallback when exact-alarm permission is unavailable

## Important background behavior
When the application process is completely stopped, App Inventor blocks cannot be executed directly from a `BroadcastReceiver`. Therefore V2 performs the alarm/notification work natively in the extension. `OnReceive` is dispatched to App Inventor when the runtime is available.

The future Binance 100-BTC monitor will be implemented natively in the background receiver so it can work when the app UI is closed.

## Build
This project follows the MIT App Inventor extension-template structure. MIT documents placing extension sources under `src/` and building with the template/dependencies. The included GitHub Actions workflow obtains the current official template and builds the `.aix` artifact.

## Test plan
1. Build `NinjaCoreAlarmManager.aix` with GitHub Actions.
2. Import the `.aix` into MIT App Inventor.
3. Request notification permission.
4. Schedule a 1-minute test alarm.
5. Lock the phone.
6. Verify the notification appears.
7. Test reboot persistence.
8. Only after these tests add the Binance Futures REST 100-BTC check.
